/**
 * Q100 - Transaction validity check
 *
 * Description: See implementation in this file.
 *
 * Example 1: Input: [500,200] => Output: true
 *
 * AUTO-GENERATED-TESTS: This header and tests block were added by tools/inject_tests.js
 */

// Q100: Check if a transaction is valid based on balance and amount
